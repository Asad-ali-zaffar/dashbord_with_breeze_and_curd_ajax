(function($){

  "use strict";

  //active
  $('#profile').addClass('active');

})(jQuery);
